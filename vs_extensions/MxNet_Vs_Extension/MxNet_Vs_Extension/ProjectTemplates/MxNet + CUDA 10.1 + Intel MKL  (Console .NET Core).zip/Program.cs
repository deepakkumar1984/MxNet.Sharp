﻿using System;
using MxNet;
using MxNet.Gluon;
using MxNet.Gluon.Losses;
using MxNet.Gluon.NN;
using MxNet.Initializers;
using MxNet.IO;
using MxNet.Metrics;
using MxNet.Optimizers;
using System.Linq;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Trainind data for XOR
            var trainX = new NDArray(new float[] { 0, 0, 0, 1, 1, 0, 1, 1 }).Reshape(4, 2);
            var trainY = new NDArray(new float[] { 0, 1, 1, 0 });

            // Define batch size
            var batch_size = 2;
            var train_data = new NDArrayIter(trainX, trainY, batch_size);
            var val_data = new NDArrayIter(trainX, trainY, batch_size);

            // Create a sequential model
            var net = new Sequential();
            net.Add(new Dense(64, ActivationType.Relu));
            net.Add(new Dense(1));

            // Define the context to train if GPU or CPU
            var gpus = TestUtils.ListGpus();
            var ctxList = gpus.Count > 0 ? gpus.Select(x => Context.Gpu(x)).ToArray() : new[] { Context.Cpu() };

            // Initialize all the weights
            net.Initialize(new Uniform(), ctxList.ToArray());
            var trainer = new Trainer(net.CollectParams(), new Adam());
            var epoch = 1000;
            var metric = new BinaryAccuracy();
            var binary_crossentropy = new LogisticLoss();
            float lossVal = 0;

            // Training loop
            for (var iter = 0; iter < epoch; iter++)
            {
                train_data.Reset();
                lossVal = 0;
                while (!train_data.End())
                {
                    var batch = train_data.Next();
                    var data = Utils.SplitAndLoad(batch.Data[0], ctxList);
                    var label = Utils.SplitAndLoad(batch.Label[0], ctxList);
                    NDArrayList outputs = null;
                    using (var ag = Autograd.Record())
                    {
                        outputs = Enumerable.Zip(data, label, (x, y) =>
                        {
                            var z = net.Call(x);
                            NDArray loss = binary_crossentropy.Call(z, y);
                            loss.Backward();
                            lossVal += loss.Mean();
                            return z;
                        }).ToList();
                    }

                    metric.Update(label, outputs.ToArray());
                    trainer.Step(batch.Data[0].Shape[0]);
                }

                var (name, acc) = metric.Get();
                metric.Reset();
                Console.WriteLine($"Loss: {lossVal}");
                Console.WriteLine($"Training acc at epoch {iter}: {name}={acc * 100}%");
            }
        }
    }
}
